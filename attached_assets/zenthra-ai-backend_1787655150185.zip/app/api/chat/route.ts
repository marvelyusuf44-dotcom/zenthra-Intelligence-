// app/api/chat/route.ts
//
// Real backend for the Zenthra AI Assistant.
// Uses Google's Gemini Interactions API (@google/genai) with function calling
// so the model can pull live data from CoinGecko, Helius, and the ZENTHRA
// signal engine before answering — instead of guessing numbers.
//
// Setup:
//   npm i @google/genai
//   Set these in your Vercel project (Settings → Environment Variables):
//     GEMINI_API_KEY     (aistudio.google.com/apikey)
//     HELIUS_API_KEY     (you already have this)
//   CoinGecko's public endpoint needs no key at this usage level.
//
// This route was written against the Gemini Interactions API docs as of
// Aug 2026 (ai.google.dev/gemini-api/docs/function-calling). Gemini model
// names change fairly often — check ai.google.dev/gemini-api/docs/models
// and update MODEL below if it's been renamed/deprecated by the time you ship.

import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";
import { getMarketData } from "@/lib/coingecko";
import { getWalletData } from "@/lib/helius";

export const maxDuration = 60;

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const MODEL = "gemini-2.5-flash";

const SYSTEM_PROMPT = `You are Zenthra, an on-chain intelligence assistant built into the Zenthra app.
You help users understand crypto markets, wallets, tokens, and trading signals using live data.
Rules:
- Never guess a number (price, balance, score). If the answer depends on real data, call a tool.
- Be direct and conversational, like a sharp analyst — not a generic customer-support bot.
- Keep answers tight. Lead with the answer, then the 1-2 facts that support it.
- If a tool returns an error, say so plainly and suggest what to try instead (e.g. a valid address).`;

const TOOLS = [
  {
    type: "function",
    name: "get_market_data",
    description: "Get live price, 24h change, market cap and volume for a crypto token.",
    parameters: {
      type: "object",
      properties: {
        symbol: {
          type: "string",
          description: "Token symbol or CoinGecko id, e.g. 'BTC', 'SOL', or 'bitcoin'",
        },
      },
      required: ["symbol"],
    },
  },
  {
    type: "function",
    name: "get_wallet_analysis",
    description: "Get SOL balance and token holdings for a Solana wallet address.",
    parameters: {
      type: "object",
      properties: {
        address: { type: "string", description: "Solana wallet address" },
      },
      required: ["address"],
    },
  },
  {
    type: "function",
    name: "get_signals",
    description:
      "Get the current ZENTHRA scoring engine signal (direction, score, entry/SL/TP) for a trading pair.",
    parameters: {
      type: "object",
      properties: {
        pair: { type: "string", description: "Trading pair, e.g. 'BTCUSDT', 'SOLUSDT'" },
      },
      required: ["pair"],
    },
  },
];

async function executeTool(name: string, args: any, origin: string) {
  try {
    switch (name) {
      case "get_market_data":
        return await getMarketData(args.symbol);

      case "get_wallet_analysis":
        return await getWalletData(args.address);

      case "get_signals": {
        // Reuses the /api/signals route already built for the Signal page —
        // keeps one source of truth for the scoring engine.
        const res = await fetch(`${origin}/api/signals?symbol=${encodeURIComponent(args.pair)}`);
        if (!res.ok) return { error: `signals API returned ${res.status}` };
        return await res.json();
      }

      default:
        return { error: `Unknown tool: ${name}` };
    }
  } catch (err: any) {
    return { error: err?.message ?? "Tool execution failed" };
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message: string = body?.message;
    const history: Array<{ role: string; text: string }> = body?.history ?? [];

    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "message is required" }, { status: 400 });
    }
    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: "GEMINI_API_KEY is not configured on the server." },
        { status: 500 }
      );
    }

    const origin = req.nextUrl.origin;

    const transcript = history
      .slice(-10) // keep the payload small; last 10 turns is plenty of context
      .map((h) => `${h.role === "user" ? "User" : "Zenthra"}: ${h.text}`)
      .join("\n");

    let interaction = await ai.interactions.create({
      model: MODEL,
      input: [
        {
          type: "user_input",
          content: [
            {
              type: "text",
              text: `${SYSTEM_PROMPT}\n\nConversation so far:\n${transcript}\n\nUser: ${message}`,
            },
          ],
        },
      ],
      tools: TOOLS,
    });

    // Resolve any tool calls the model makes, feeding results back until it
    // gives a final text answer. Capped so a stuck loop can't hang the request.
    let guard = 0;
    while (interaction.steps.some((s: any) => s.type === "function_call") && guard < 4) {
      const calls = interaction.steps.filter((s: any) => s.type === "function_call");

      const results = await Promise.all(
        calls.map(async (fc: any) => ({
          type: "function_result",
          name: fc.name,
          call_id: fc.id,
          result: [
            { type: "text", text: JSON.stringify(await executeTool(fc.name, fc.arguments, origin)) },
          ],
        }))
      );

      interaction = await ai.interactions.create({
        model: MODEL,
        input: results,
        tools: TOOLS,
        previous_interaction_id: interaction.id,
      });

      guard++;
    }

    return NextResponse.json({
      reply: interaction.output_text || "I couldn't generate a response — try rephrasing that.",
    });
  } catch (err: any) {
    console.error("[/api/chat] error:", err);
    return NextResponse.json(
      { error: "Something went wrong talking to Zenthra AI." },
      { status: 500 }
    );
  }
}
