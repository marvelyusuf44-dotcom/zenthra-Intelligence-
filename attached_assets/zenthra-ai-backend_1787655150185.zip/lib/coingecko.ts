// lib/coingecko.ts
// Free public CoinGecko endpoints — no API key required for this usage level.
// If you add a Demo API key later, send it via header: "x-cg-demo-api-key".

const BASE = "https://api.coingecko.com/api/v3";

// Common symbol -> CoinGecko id map. Extend as needed; unmapped symbols are
// tried as-is (CoinGecko ids are usually lowercase-hyphenated, e.g. "jupiter-exchange-solana").
const SYMBOL_TO_ID: Record<string, string> = {
  BTC: "bitcoin",
  ETH: "ethereum",
  SOL: "solana",
  BNB: "binancecoin",
  XRP: "ripple",
  DOGE: "dogecoin",
  JUP: "jupiter-exchange-solana",
  BONK: "bonk",
  USDC: "usd-coin",
  USDT: "tether",
};

export async function getMarketData(symbolOrId: string) {
  const id = SYMBOL_TO_ID[symbolOrId.toUpperCase()] ?? symbolOrId.toLowerCase();
  const url = `${BASE}/coins/markets?vs_currency=usd&ids=${encodeURIComponent(id)}`;

  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (!res.ok) {
    return { error: `CoinGecko request failed (${res.status})` };
  }

  const data = await res.json();
  const coin = Array.isArray(data) ? data[0] : null;
  if (!coin) {
    return { error: `Token "${symbolOrId}" not found on CoinGecko` };
  }

  return {
    name: coin.name,
    symbol: (coin.symbol || "").toUpperCase(),
    price: coin.current_price,
    change24h: coin.price_change_percentage_24h,
    marketCap: coin.market_cap,
    marketCapRank: coin.market_cap_rank,
    volume24h: coin.total_volume,
  };
}

export async function getTopMarkets(limit = 10) {
  const url = `${BASE}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${limit}&page=1`;
  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (!res.ok) {
    return { error: `CoinGecko request failed (${res.status})` };
  }
  const data = await res.json();
  return (data as any[]).map((d) => ({
    name: d.name,
    symbol: (d.symbol || "").toUpperCase(),
    price: d.current_price,
    change24h: d.price_change_percentage_24h,
    marketCap: d.market_cap,
    volume24h: d.total_volume,
  }));
}
