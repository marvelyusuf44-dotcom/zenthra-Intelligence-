// lib/helius.ts
// Solana wallet data via Helius DAS API (getAssetsByOwner).
// Requires HELIUS_API_KEY in your environment (Vercel project settings).

const HELIUS_KEY = process.env.HELIUS_API_KEY;

export async function getWalletData(address: string) {
  if (!HELIUS_KEY) {
    return { error: "HELIUS_API_KEY is not configured on the server." };
  }

  const url = `https://mainnet.helius-rpc.com/?api-key=${HELIUS_KEY}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "zenthra",
      method: "getAssetsByOwner",
      params: {
        ownerAddress: address,
        page: 1,
        limit: 50,
        displayOptions: {
          showFungible: true,
          showNativeBalance: true,
        },
      },
    }),
  });

  if (!res.ok) {
    return { error: `Helius request failed (${res.status})` };
  }

  const { result, error } = await res.json();
  if (error) return { error: error.message || "Helius returned an error" };
  if (!result) return { error: "No data returned for this address" };

  const lamports = result.nativeBalance?.lamports ?? 0;
  const solBalance = lamports / 1e9;

  const tokens = (result.items ?? [])
    .filter((it: any) => it.interface === "FungibleToken" || it.interface === "FungibleAsset")
    .slice(0, 10)
    .map((it: any) => {
      const decimals = it.token_info?.decimals;
      const rawBalance = it.token_info?.balance;
      return {
        name: it.content?.metadata?.name || "Unknown token",
        symbol: it.token_info?.symbol || "",
        amount:
          typeof rawBalance === "number" && typeof decimals === "number"
            ? rawBalance / 10 ** decimals
            : null,
      };
    });

  return {
    address,
    solBalance,
    tokenCount: tokens.length,
    tokens,
  };
}
